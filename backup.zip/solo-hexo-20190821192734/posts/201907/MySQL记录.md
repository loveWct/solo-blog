title: MySQL 记录
date: '2019-07-29 12:55:36'
updated: '2019-07-29 12:55:36'
tags: [MySQL, 读书, MySQL技术内幕]
permalink: /articles/2019/07/29/1564376136423.html
---
![](https://img.hacpai.com/bing/20180825.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 命令行小技巧
1. \c参数，清除正在使用的命令行
2. \G参数，垂直输出查询数据
3. source，执行SQL文件
4. LOAD DATA LOCAL INFILE "文件名.txt" INFO TABLE 表名 加载txt文件，假定已经设置好了对应的格式
##### 冷门小知识
1. SQL模式设置 set sql_mode
2. MySql可以进行分区，分区函数具有确定性语法。
3. 可以用Any，Some，All进行子查询的比较，exists和no exists进行子查询判空
4. union合并结果集
5. set autocommit=1；设置事务自动提交
6. InnoDB默认的事务隔离级别是repeatable read
7. 创建表在设置主外键的时候，添加on delete cascade设置级联删除或类似的级联修改
8. mysql5.6以后，添加fulltext全文索引
9. 支持空间值设定，假如 坐标
10. 在查询语句中，表明后，添加force index ，use index，ignore index等等，实现手动对索引的选择
11. select * from table proceduce analyse() 可以输出有关于表各列的信息，从而选择最佳列
12. show variables like 'datadir'查找数据目录
13. have_query_cache 语法同上，查看是否启用了查询缓存
14. DELIMITER \\ 命令行工具中的自定义断句符号